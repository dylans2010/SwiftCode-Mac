// Compatibility Verification Fixture for macos16-future - Target 8

public struct CompatEntity_macos16_future_08_0000: Sendable, Codable {
    public let id: String = "macos16-future.8.0"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0001: Sendable, Codable {
    public let id: String = "macos16-future.8.1"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0002: Sendable, Codable {
    public let id: String = "macos16-future.8.2"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0003: Sendable, Codable {
    public let id: String = "macos16-future.8.3"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0004: Sendable, Codable {
    public let id: String = "macos16-future.8.4"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0005: Sendable, Codable {
    public let id: String = "macos16-future.8.5"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0006: Sendable, Codable {
    public let id: String = "macos16-future.8.6"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0007: Sendable, Codable {
    public let id: String = "macos16-future.8.7"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0008: Sendable, Codable {
    public let id: String = "macos16-future.8.8"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0009: Sendable, Codable {
    public let id: String = "macos16-future.8.9"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0010: Sendable, Codable {
    public let id: String = "macos16-future.8.10"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0011: Sendable, Codable {
    public let id: String = "macos16-future.8.11"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0012: Sendable, Codable {
    public let id: String = "macos16-future.8.12"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0013: Sendable, Codable {
    public let id: String = "macos16-future.8.13"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0014: Sendable, Codable {
    public let id: String = "macos16-future.8.14"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0015: Sendable, Codable {
    public let id: String = "macos16-future.8.15"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0016: Sendable, Codable {
    public let id: String = "macos16-future.8.16"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0017: Sendable, Codable {
    public let id: String = "macos16-future.8.17"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0018: Sendable, Codable {
    public let id: String = "macos16-future.8.18"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0019: Sendable, Codable {
    public let id: String = "macos16-future.8.19"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0020: Sendable, Codable {
    public let id: String = "macos16-future.8.20"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0021: Sendable, Codable {
    public let id: String = "macos16-future.8.21"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0022: Sendable, Codable {
    public let id: String = "macos16-future.8.22"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0023: Sendable, Codable {
    public let id: String = "macos16-future.8.23"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0024: Sendable, Codable {
    public let id: String = "macos16-future.8.24"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0025: Sendable, Codable {
    public let id: String = "macos16-future.8.25"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0026: Sendable, Codable {
    public let id: String = "macos16-future.8.26"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0027: Sendable, Codable {
    public let id: String = "macos16-future.8.27"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0028: Sendable, Codable {
    public let id: String = "macos16-future.8.28"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0029: Sendable, Codable {
    public let id: String = "macos16-future.8.29"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0030: Sendable, Codable {
    public let id: String = "macos16-future.8.30"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0031: Sendable, Codable {
    public let id: String = "macos16-future.8.31"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0032: Sendable, Codable {
    public let id: String = "macos16-future.8.32"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0033: Sendable, Codable {
    public let id: String = "macos16-future.8.33"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0034: Sendable, Codable {
    public let id: String = "macos16-future.8.34"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0035: Sendable, Codable {
    public let id: String = "macos16-future.8.35"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0036: Sendable, Codable {
    public let id: String = "macos16-future.8.36"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0037: Sendable, Codable {
    public let id: String = "macos16-future.8.37"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0038: Sendable, Codable {
    public let id: String = "macos16-future.8.38"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0039: Sendable, Codable {
    public let id: String = "macos16-future.8.39"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0040: Sendable, Codable {
    public let id: String = "macos16-future.8.40"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0041: Sendable, Codable {
    public let id: String = "macos16-future.8.41"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0042: Sendable, Codable {
    public let id: String = "macos16-future.8.42"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0043: Sendable, Codable {
    public let id: String = "macos16-future.8.43"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0044: Sendable, Codable {
    public let id: String = "macos16-future.8.44"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0045: Sendable, Codable {
    public let id: String = "macos16-future.8.45"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0046: Sendable, Codable {
    public let id: String = "macos16-future.8.46"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0047: Sendable, Codable {
    public let id: String = "macos16-future.8.47"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0048: Sendable, Codable {
    public let id: String = "macos16-future.8.48"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0049: Sendable, Codable {
    public let id: String = "macos16-future.8.49"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0050: Sendable, Codable {
    public let id: String = "macos16-future.8.50"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0051: Sendable, Codable {
    public let id: String = "macos16-future.8.51"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0052: Sendable, Codable {
    public let id: String = "macos16-future.8.52"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0053: Sendable, Codable {
    public let id: String = "macos16-future.8.53"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0054: Sendable, Codable {
    public let id: String = "macos16-future.8.54"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0055: Sendable, Codable {
    public let id: String = "macos16-future.8.55"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0056: Sendable, Codable {
    public let id: String = "macos16-future.8.56"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0057: Sendable, Codable {
    public let id: String = "macos16-future.8.57"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0058: Sendable, Codable {
    public let id: String = "macos16-future.8.58"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0059: Sendable, Codable {
    public let id: String = "macos16-future.8.59"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0060: Sendable, Codable {
    public let id: String = "macos16-future.8.60"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0061: Sendable, Codable {
    public let id: String = "macos16-future.8.61"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0062: Sendable, Codable {
    public let id: String = "macos16-future.8.62"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0063: Sendable, Codable {
    public let id: String = "macos16-future.8.63"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0064: Sendable, Codable {
    public let id: String = "macos16-future.8.64"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0065: Sendable, Codable {
    public let id: String = "macos16-future.8.65"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0066: Sendable, Codable {
    public let id: String = "macos16-future.8.66"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0067: Sendable, Codable {
    public let id: String = "macos16-future.8.67"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0068: Sendable, Codable {
    public let id: String = "macos16-future.8.68"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0069: Sendable, Codable {
    public let id: String = "macos16-future.8.69"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0070: Sendable, Codable {
    public let id: String = "macos16-future.8.70"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0071: Sendable, Codable {
    public let id: String = "macos16-future.8.71"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0072: Sendable, Codable {
    public let id: String = "macos16-future.8.72"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0073: Sendable, Codable {
    public let id: String = "macos16-future.8.73"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0074: Sendable, Codable {
    public let id: String = "macos16-future.8.74"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0075: Sendable, Codable {
    public let id: String = "macos16-future.8.75"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0076: Sendable, Codable {
    public let id: String = "macos16-future.8.76"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0077: Sendable, Codable {
    public let id: String = "macos16-future.8.77"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0078: Sendable, Codable {
    public let id: String = "macos16-future.8.78"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0079: Sendable, Codable {
    public let id: String = "macos16-future.8.79"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0080: Sendable, Codable {
    public let id: String = "macos16-future.8.80"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0081: Sendable, Codable {
    public let id: String = "macos16-future.8.81"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0082: Sendable, Codable {
    public let id: String = "macos16-future.8.82"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0083: Sendable, Codable {
    public let id: String = "macos16-future.8.83"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0084: Sendable, Codable {
    public let id: String = "macos16-future.8.84"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0085: Sendable, Codable {
    public let id: String = "macos16-future.8.85"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0086: Sendable, Codable {
    public let id: String = "macos16-future.8.86"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0087: Sendable, Codable {
    public let id: String = "macos16-future.8.87"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0088: Sendable, Codable {
    public let id: String = "macos16-future.8.88"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0089: Sendable, Codable {
    public let id: String = "macos16-future.8.89"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0090: Sendable, Codable {
    public let id: String = "macos16-future.8.90"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0091: Sendable, Codable {
    public let id: String = "macos16-future.8.91"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0092: Sendable, Codable {
    public let id: String = "macos16-future.8.92"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0093: Sendable, Codable {
    public let id: String = "macos16-future.8.93"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0094: Sendable, Codable {
    public let id: String = "macos16-future.8.94"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0095: Sendable, Codable {
    public let id: String = "macos16-future.8.95"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0096: Sendable, Codable {
    public let id: String = "macos16-future.8.96"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0097: Sendable, Codable {
    public let id: String = "macos16-future.8.97"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0098: Sendable, Codable {
    public let id: String = "macos16-future.8.98"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0099: Sendable, Codable {
    public let id: String = "macos16-future.8.99"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0100: Sendable, Codable {
    public let id: String = "macos16-future.8.100"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0101: Sendable, Codable {
    public let id: String = "macos16-future.8.101"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0102: Sendable, Codable {
    public let id: String = "macos16-future.8.102"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0103: Sendable, Codable {
    public let id: String = "macos16-future.8.103"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0104: Sendable, Codable {
    public let id: String = "macos16-future.8.104"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0105: Sendable, Codable {
    public let id: String = "macos16-future.8.105"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0106: Sendable, Codable {
    public let id: String = "macos16-future.8.106"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0107: Sendable, Codable {
    public let id: String = "macos16-future.8.107"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0108: Sendable, Codable {
    public let id: String = "macos16-future.8.108"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0109: Sendable, Codable {
    public let id: String = "macos16-future.8.109"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0110: Sendable, Codable {
    public let id: String = "macos16-future.8.110"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0111: Sendable, Codable {
    public let id: String = "macos16-future.8.111"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0112: Sendable, Codable {
    public let id: String = "macos16-future.8.112"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0113: Sendable, Codable {
    public let id: String = "macos16-future.8.113"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0114: Sendable, Codable {
    public let id: String = "macos16-future.8.114"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0115: Sendable, Codable {
    public let id: String = "macos16-future.8.115"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0116: Sendable, Codable {
    public let id: String = "macos16-future.8.116"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0117: Sendable, Codable {
    public let id: String = "macos16-future.8.117"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0118: Sendable, Codable {
    public let id: String = "macos16-future.8.118"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0119: Sendable, Codable {
    public let id: String = "macos16-future.8.119"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0120: Sendable, Codable {
    public let id: String = "macos16-future.8.120"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0121: Sendable, Codable {
    public let id: String = "macos16-future.8.121"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0122: Sendable, Codable {
    public let id: String = "macos16-future.8.122"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0123: Sendable, Codable {
    public let id: String = "macos16-future.8.123"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0124: Sendable, Codable {
    public let id: String = "macos16-future.8.124"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0125: Sendable, Codable {
    public let id: String = "macos16-future.8.125"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0126: Sendable, Codable {
    public let id: String = "macos16-future.8.126"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0127: Sendable, Codable {
    public let id: String = "macos16-future.8.127"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0128: Sendable, Codable {
    public let id: String = "macos16-future.8.128"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0129: Sendable, Codable {
    public let id: String = "macos16-future.8.129"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0130: Sendable, Codable {
    public let id: String = "macos16-future.8.130"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0131: Sendable, Codable {
    public let id: String = "macos16-future.8.131"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0132: Sendable, Codable {
    public let id: String = "macos16-future.8.132"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0133: Sendable, Codable {
    public let id: String = "macos16-future.8.133"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0134: Sendable, Codable {
    public let id: String = "macos16-future.8.134"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0135: Sendable, Codable {
    public let id: String = "macos16-future.8.135"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0136: Sendable, Codable {
    public let id: String = "macos16-future.8.136"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0137: Sendable, Codable {
    public let id: String = "macos16-future.8.137"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0138: Sendable, Codable {
    public let id: String = "macos16-future.8.138"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0139: Sendable, Codable {
    public let id: String = "macos16-future.8.139"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0140: Sendable, Codable {
    public let id: String = "macos16-future.8.140"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0141: Sendable, Codable {
    public let id: String = "macos16-future.8.141"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0142: Sendable, Codable {
    public let id: String = "macos16-future.8.142"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0143: Sendable, Codable {
    public let id: String = "macos16-future.8.143"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0144: Sendable, Codable {
    public let id: String = "macos16-future.8.144"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0145: Sendable, Codable {
    public let id: String = "macos16-future.8.145"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0146: Sendable, Codable {
    public let id: String = "macos16-future.8.146"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0147: Sendable, Codable {
    public let id: String = "macos16-future.8.147"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0148: Sendable, Codable {
    public let id: String = "macos16-future.8.148"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0149: Sendable, Codable {
    public let id: String = "macos16-future.8.149"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0150: Sendable, Codable {
    public let id: String = "macos16-future.8.150"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0151: Sendable, Codable {
    public let id: String = "macos16-future.8.151"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0152: Sendable, Codable {
    public let id: String = "macos16-future.8.152"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0153: Sendable, Codable {
    public let id: String = "macos16-future.8.153"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0154: Sendable, Codable {
    public let id: String = "macos16-future.8.154"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0155: Sendable, Codable {
    public let id: String = "macos16-future.8.155"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0156: Sendable, Codable {
    public let id: String = "macos16-future.8.156"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0157: Sendable, Codable {
    public let id: String = "macos16-future.8.157"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0158: Sendable, Codable {
    public let id: String = "macos16-future.8.158"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0159: Sendable, Codable {
    public let id: String = "macos16-future.8.159"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0160: Sendable, Codable {
    public let id: String = "macos16-future.8.160"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0161: Sendable, Codable {
    public let id: String = "macos16-future.8.161"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0162: Sendable, Codable {
    public let id: String = "macos16-future.8.162"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0163: Sendable, Codable {
    public let id: String = "macos16-future.8.163"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0164: Sendable, Codable {
    public let id: String = "macos16-future.8.164"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0165: Sendable, Codable {
    public let id: String = "macos16-future.8.165"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0166: Sendable, Codable {
    public let id: String = "macos16-future.8.166"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0167: Sendable, Codable {
    public let id: String = "macos16-future.8.167"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0168: Sendable, Codable {
    public let id: String = "macos16-future.8.168"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0169: Sendable, Codable {
    public let id: String = "macos16-future.8.169"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0170: Sendable, Codable {
    public let id: String = "macos16-future.8.170"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0171: Sendable, Codable {
    public let id: String = "macos16-future.8.171"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0172: Sendable, Codable {
    public let id: String = "macos16-future.8.172"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0173: Sendable, Codable {
    public let id: String = "macos16-future.8.173"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0174: Sendable, Codable {
    public let id: String = "macos16-future.8.174"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0175: Sendable, Codable {
    public let id: String = "macos16-future.8.175"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0176: Sendable, Codable {
    public let id: String = "macos16-future.8.176"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0177: Sendable, Codable {
    public let id: String = "macos16-future.8.177"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0178: Sendable, Codable {
    public let id: String = "macos16-future.8.178"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0179: Sendable, Codable {
    public let id: String = "macos16-future.8.179"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0180: Sendable, Codable {
    public let id: String = "macos16-future.8.180"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0181: Sendable, Codable {
    public let id: String = "macos16-future.8.181"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0182: Sendable, Codable {
    public let id: String = "macos16-future.8.182"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0183: Sendable, Codable {
    public let id: String = "macos16-future.8.183"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0184: Sendable, Codable {
    public let id: String = "macos16-future.8.184"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0185: Sendable, Codable {
    public let id: String = "macos16-future.8.185"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0186: Sendable, Codable {
    public let id: String = "macos16-future.8.186"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0187: Sendable, Codable {
    public let id: String = "macos16-future.8.187"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0188: Sendable, Codable {
    public let id: String = "macos16-future.8.188"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0189: Sendable, Codable {
    public let id: String = "macos16-future.8.189"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0190: Sendable, Codable {
    public let id: String = "macos16-future.8.190"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0191: Sendable, Codable {
    public let id: String = "macos16-future.8.191"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0192: Sendable, Codable {
    public let id: String = "macos16-future.8.192"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0193: Sendable, Codable {
    public let id: String = "macos16-future.8.193"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0194: Sendable, Codable {
    public let id: String = "macos16-future.8.194"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0195: Sendable, Codable {
    public let id: String = "macos16-future.8.195"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0196: Sendable, Codable {
    public let id: String = "macos16-future.8.196"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0197: Sendable, Codable {
    public let id: String = "macos16-future.8.197"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0198: Sendable, Codable {
    public let id: String = "macos16-future.8.198"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0199: Sendable, Codable {
    public let id: String = "macos16-future.8.199"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0200: Sendable, Codable {
    public let id: String = "macos16-future.8.200"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0201: Sendable, Codable {
    public let id: String = "macos16-future.8.201"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0202: Sendable, Codable {
    public let id: String = "macos16-future.8.202"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0203: Sendable, Codable {
    public let id: String = "macos16-future.8.203"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0204: Sendable, Codable {
    public let id: String = "macos16-future.8.204"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0205: Sendable, Codable {
    public let id: String = "macos16-future.8.205"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0206: Sendable, Codable {
    public let id: String = "macos16-future.8.206"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0207: Sendable, Codable {
    public let id: String = "macos16-future.8.207"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0208: Sendable, Codable {
    public let id: String = "macos16-future.8.208"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0209: Sendable, Codable {
    public let id: String = "macos16-future.8.209"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0210: Sendable, Codable {
    public let id: String = "macos16-future.8.210"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0211: Sendable, Codable {
    public let id: String = "macos16-future.8.211"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0212: Sendable, Codable {
    public let id: String = "macos16-future.8.212"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0213: Sendable, Codable {
    public let id: String = "macos16-future.8.213"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0214: Sendable, Codable {
    public let id: String = "macos16-future.8.214"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0215: Sendable, Codable {
    public let id: String = "macos16-future.8.215"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0216: Sendable, Codable {
    public let id: String = "macos16-future.8.216"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0217: Sendable, Codable {
    public let id: String = "macos16-future.8.217"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0218: Sendable, Codable {
    public let id: String = "macos16-future.8.218"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0219: Sendable, Codable {
    public let id: String = "macos16-future.8.219"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0220: Sendable, Codable {
    public let id: String = "macos16-future.8.220"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0221: Sendable, Codable {
    public let id: String = "macos16-future.8.221"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0222: Sendable, Codable {
    public let id: String = "macos16-future.8.222"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0223: Sendable, Codable {
    public let id: String = "macos16-future.8.223"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0224: Sendable, Codable {
    public let id: String = "macos16-future.8.224"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0225: Sendable, Codable {
    public let id: String = "macos16-future.8.225"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0226: Sendable, Codable {
    public let id: String = "macos16-future.8.226"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0227: Sendable, Codable {
    public let id: String = "macos16-future.8.227"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0228: Sendable, Codable {
    public let id: String = "macos16-future.8.228"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0229: Sendable, Codable {
    public let id: String = "macos16-future.8.229"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0230: Sendable, Codable {
    public let id: String = "macos16-future.8.230"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0231: Sendable, Codable {
    public let id: String = "macos16-future.8.231"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0232: Sendable, Codable {
    public let id: String = "macos16-future.8.232"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0233: Sendable, Codable {
    public let id: String = "macos16-future.8.233"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0234: Sendable, Codable {
    public let id: String = "macos16-future.8.234"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0235: Sendable, Codable {
    public let id: String = "macos16-future.8.235"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0236: Sendable, Codable {
    public let id: String = "macos16-future.8.236"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0237: Sendable, Codable {
    public let id: String = "macos16-future.8.237"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0238: Sendable, Codable {
    public let id: String = "macos16-future.8.238"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0239: Sendable, Codable {
    public let id: String = "macos16-future.8.239"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0240: Sendable, Codable {
    public let id: String = "macos16-future.8.240"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0241: Sendable, Codable {
    public let id: String = "macos16-future.8.241"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0242: Sendable, Codable {
    public let id: String = "macos16-future.8.242"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0243: Sendable, Codable {
    public let id: String = "macos16-future.8.243"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0244: Sendable, Codable {
    public let id: String = "macos16-future.8.244"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0245: Sendable, Codable {
    public let id: String = "macos16-future.8.245"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0246: Sendable, Codable {
    public let id: String = "macos16-future.8.246"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0247: Sendable, Codable {
    public let id: String = "macos16-future.8.247"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0248: Sendable, Codable {
    public let id: String = "macos16-future.8.248"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0249: Sendable, Codable {
    public let id: String = "macos16-future.8.249"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0250: Sendable, Codable {
    public let id: String = "macos16-future.8.250"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0251: Sendable, Codable {
    public let id: String = "macos16-future.8.251"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0252: Sendable, Codable {
    public let id: String = "macos16-future.8.252"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0253: Sendable, Codable {
    public let id: String = "macos16-future.8.253"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0254: Sendable, Codable {
    public let id: String = "macos16-future.8.254"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0255: Sendable, Codable {
    public let id: String = "macos16-future.8.255"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0256: Sendable, Codable {
    public let id: String = "macos16-future.8.256"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0257: Sendable, Codable {
    public let id: String = "macos16-future.8.257"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0258: Sendable, Codable {
    public let id: String = "macos16-future.8.258"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0259: Sendable, Codable {
    public let id: String = "macos16-future.8.259"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0260: Sendable, Codable {
    public let id: String = "macos16-future.8.260"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0261: Sendable, Codable {
    public let id: String = "macos16-future.8.261"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0262: Sendable, Codable {
    public let id: String = "macos16-future.8.262"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0263: Sendable, Codable {
    public let id: String = "macos16-future.8.263"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0264: Sendable, Codable {
    public let id: String = "macos16-future.8.264"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0265: Sendable, Codable {
    public let id: String = "macos16-future.8.265"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0266: Sendable, Codable {
    public let id: String = "macos16-future.8.266"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0267: Sendable, Codable {
    public let id: String = "macos16-future.8.267"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0268: Sendable, Codable {
    public let id: String = "macos16-future.8.268"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0269: Sendable, Codable {
    public let id: String = "macos16-future.8.269"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0270: Sendable, Codable {
    public let id: String = "macos16-future.8.270"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0271: Sendable, Codable {
    public let id: String = "macos16-future.8.271"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0272: Sendable, Codable {
    public let id: String = "macos16-future.8.272"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0273: Sendable, Codable {
    public let id: String = "macos16-future.8.273"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0274: Sendable, Codable {
    public let id: String = "macos16-future.8.274"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0275: Sendable, Codable {
    public let id: String = "macos16-future.8.275"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0276: Sendable, Codable {
    public let id: String = "macos16-future.8.276"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0277: Sendable, Codable {
    public let id: String = "macos16-future.8.277"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0278: Sendable, Codable {
    public let id: String = "macos16-future.8.278"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0279: Sendable, Codable {
    public let id: String = "macos16-future.8.279"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0280: Sendable, Codable {
    public let id: String = "macos16-future.8.280"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0281: Sendable, Codable {
    public let id: String = "macos16-future.8.281"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0282: Sendable, Codable {
    public let id: String = "macos16-future.8.282"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0283: Sendable, Codable {
    public let id: String = "macos16-future.8.283"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0284: Sendable, Codable {
    public let id: String = "macos16-future.8.284"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0285: Sendable, Codable {
    public let id: String = "macos16-future.8.285"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0286: Sendable, Codable {
    public let id: String = "macos16-future.8.286"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0287: Sendable, Codable {
    public let id: String = "macos16-future.8.287"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0288: Sendable, Codable {
    public let id: String = "macos16-future.8.288"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0289: Sendable, Codable {
    public let id: String = "macos16-future.8.289"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0290: Sendable, Codable {
    public let id: String = "macos16-future.8.290"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0291: Sendable, Codable {
    public let id: String = "macos16-future.8.291"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0292: Sendable, Codable {
    public let id: String = "macos16-future.8.292"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0293: Sendable, Codable {
    public let id: String = "macos16-future.8.293"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0294: Sendable, Codable {
    public let id: String = "macos16-future.8.294"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0295: Sendable, Codable {
    public let id: String = "macos16-future.8.295"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0296: Sendable, Codable {
    public let id: String = "macos16-future.8.296"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0297: Sendable, Codable {
    public let id: String = "macos16-future.8.297"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0298: Sendable, Codable {
    public let id: String = "macos16-future.8.298"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0299: Sendable, Codable {
    public let id: String = "macos16-future.8.299"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0300: Sendable, Codable {
    public let id: String = "macos16-future.8.300"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0301: Sendable, Codable {
    public let id: String = "macos16-future.8.301"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0302: Sendable, Codable {
    public let id: String = "macos16-future.8.302"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0303: Sendable, Codable {
    public let id: String = "macos16-future.8.303"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0304: Sendable, Codable {
    public let id: String = "macos16-future.8.304"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0305: Sendable, Codable {
    public let id: String = "macos16-future.8.305"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0306: Sendable, Codable {
    public let id: String = "macos16-future.8.306"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0307: Sendable, Codable {
    public let id: String = "macos16-future.8.307"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0308: Sendable, Codable {
    public let id: String = "macos16-future.8.308"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0309: Sendable, Codable {
    public let id: String = "macos16-future.8.309"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0310: Sendable, Codable {
    public let id: String = "macos16-future.8.310"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0311: Sendable, Codable {
    public let id: String = "macos16-future.8.311"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0312: Sendable, Codable {
    public let id: String = "macos16-future.8.312"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0313: Sendable, Codable {
    public let id: String = "macos16-future.8.313"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0314: Sendable, Codable {
    public let id: String = "macos16-future.8.314"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0315: Sendable, Codable {
    public let id: String = "macos16-future.8.315"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0316: Sendable, Codable {
    public let id: String = "macos16-future.8.316"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0317: Sendable, Codable {
    public let id: String = "macos16-future.8.317"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0318: Sendable, Codable {
    public let id: String = "macos16-future.8.318"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0319: Sendable, Codable {
    public let id: String = "macos16-future.8.319"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0320: Sendable, Codable {
    public let id: String = "macos16-future.8.320"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0321: Sendable, Codable {
    public let id: String = "macos16-future.8.321"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0322: Sendable, Codable {
    public let id: String = "macos16-future.8.322"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0323: Sendable, Codable {
    public let id: String = "macos16-future.8.323"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0324: Sendable, Codable {
    public let id: String = "macos16-future.8.324"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0325: Sendable, Codable {
    public let id: String = "macos16-future.8.325"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0326: Sendable, Codable {
    public let id: String = "macos16-future.8.326"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0327: Sendable, Codable {
    public let id: String = "macos16-future.8.327"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0328: Sendable, Codable {
    public let id: String = "macos16-future.8.328"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0329: Sendable, Codable {
    public let id: String = "macos16-future.8.329"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0330: Sendable, Codable {
    public let id: String = "macos16-future.8.330"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0331: Sendable, Codable {
    public let id: String = "macos16-future.8.331"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0332: Sendable, Codable {
    public let id: String = "macos16-future.8.332"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0333: Sendable, Codable {
    public let id: String = "macos16-future.8.333"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0334: Sendable, Codable {
    public let id: String = "macos16-future.8.334"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0335: Sendable, Codable {
    public let id: String = "macos16-future.8.335"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0336: Sendable, Codable {
    public let id: String = "macos16-future.8.336"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0337: Sendable, Codable {
    public let id: String = "macos16-future.8.337"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0338: Sendable, Codable {
    public let id: String = "macos16-future.8.338"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0339: Sendable, Codable {
    public let id: String = "macos16-future.8.339"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0340: Sendable, Codable {
    public let id: String = "macos16-future.8.340"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0341: Sendable, Codable {
    public let id: String = "macos16-future.8.341"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0342: Sendable, Codable {
    public let id: String = "macos16-future.8.342"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0343: Sendable, Codable {
    public let id: String = "macos16-future.8.343"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0344: Sendable, Codable {
    public let id: String = "macos16-future.8.344"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0345: Sendable, Codable {
    public let id: String = "macos16-future.8.345"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0346: Sendable, Codable {
    public let id: String = "macos16-future.8.346"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0347: Sendable, Codable {
    public let id: String = "macos16-future.8.347"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0348: Sendable, Codable {
    public let id: String = "macos16-future.8.348"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0349: Sendable, Codable {
    public let id: String = "macos16-future.8.349"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0350: Sendable, Codable {
    public let id: String = "macos16-future.8.350"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0351: Sendable, Codable {
    public let id: String = "macos16-future.8.351"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0352: Sendable, Codable {
    public let id: String = "macos16-future.8.352"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0353: Sendable, Codable {
    public let id: String = "macos16-future.8.353"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0354: Sendable, Codable {
    public let id: String = "macos16-future.8.354"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0355: Sendable, Codable {
    public let id: String = "macos16-future.8.355"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0356: Sendable, Codable {
    public let id: String = "macos16-future.8.356"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0357: Sendable, Codable {
    public let id: String = "macos16-future.8.357"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0358: Sendable, Codable {
    public let id: String = "macos16-future.8.358"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0359: Sendable, Codable {
    public let id: String = "macos16-future.8.359"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0360: Sendable, Codable {
    public let id: String = "macos16-future.8.360"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0361: Sendable, Codable {
    public let id: String = "macos16-future.8.361"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0362: Sendable, Codable {
    public let id: String = "macos16-future.8.362"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0363: Sendable, Codable {
    public let id: String = "macos16-future.8.363"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0364: Sendable, Codable {
    public let id: String = "macos16-future.8.364"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0365: Sendable, Codable {
    public let id: String = "macos16-future.8.365"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0366: Sendable, Codable {
    public let id: String = "macos16-future.8.366"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0367: Sendable, Codable {
    public let id: String = "macos16-future.8.367"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0368: Sendable, Codable {
    public let id: String = "macos16-future.8.368"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0369: Sendable, Codable {
    public let id: String = "macos16-future.8.369"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0370: Sendable, Codable {
    public let id: String = "macos16-future.8.370"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0371: Sendable, Codable {
    public let id: String = "macos16-future.8.371"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0372: Sendable, Codable {
    public let id: String = "macos16-future.8.372"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0373: Sendable, Codable {
    public let id: String = "macos16-future.8.373"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0374: Sendable, Codable {
    public let id: String = "macos16-future.8.374"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0375: Sendable, Codable {
    public let id: String = "macos16-future.8.375"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0376: Sendable, Codable {
    public let id: String = "macos16-future.8.376"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0377: Sendable, Codable {
    public let id: String = "macos16-future.8.377"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0378: Sendable, Codable {
    public let id: String = "macos16-future.8.378"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0379: Sendable, Codable {
    public let id: String = "macos16-future.8.379"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0380: Sendable, Codable {
    public let id: String = "macos16-future.8.380"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0381: Sendable, Codable {
    public let id: String = "macos16-future.8.381"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0382: Sendable, Codable {
    public let id: String = "macos16-future.8.382"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0383: Sendable, Codable {
    public let id: String = "macos16-future.8.383"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0384: Sendable, Codable {
    public let id: String = "macos16-future.8.384"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0385: Sendable, Codable {
    public let id: String = "macos16-future.8.385"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0386: Sendable, Codable {
    public let id: String = "macos16-future.8.386"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0387: Sendable, Codable {
    public let id: String = "macos16-future.8.387"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0388: Sendable, Codable {
    public let id: String = "macos16-future.8.388"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0389: Sendable, Codable {
    public let id: String = "macos16-future.8.389"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0390: Sendable, Codable {
    public let id: String = "macos16-future.8.390"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0391: Sendable, Codable {
    public let id: String = "macos16-future.8.391"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0392: Sendable, Codable {
    public let id: String = "macos16-future.8.392"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0393: Sendable, Codable {
    public let id: String = "macos16-future.8.393"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0394: Sendable, Codable {
    public let id: String = "macos16-future.8.394"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0395: Sendable, Codable {
    public let id: String = "macos16-future.8.395"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0396: Sendable, Codable {
    public let id: String = "macos16-future.8.396"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0397: Sendable, Codable {
    public let id: String = "macos16-future.8.397"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0398: Sendable, Codable {
    public let id: String = "macos16-future.8.398"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0399: Sendable, Codable {
    public let id: String = "macos16-future.8.399"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0400: Sendable, Codable {
    public let id: String = "macos16-future.8.400"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0401: Sendable, Codable {
    public let id: String = "macos16-future.8.401"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0402: Sendable, Codable {
    public let id: String = "macos16-future.8.402"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0403: Sendable, Codable {
    public let id: String = "macos16-future.8.403"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0404: Sendable, Codable {
    public let id: String = "macos16-future.8.404"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0405: Sendable, Codable {
    public let id: String = "macos16-future.8.405"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0406: Sendable, Codable {
    public let id: String = "macos16-future.8.406"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0407: Sendable, Codable {
    public let id: String = "macos16-future.8.407"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0408: Sendable, Codable {
    public let id: String = "macos16-future.8.408"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0409: Sendable, Codable {
    public let id: String = "macos16-future.8.409"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0410: Sendable, Codable {
    public let id: String = "macos16-future.8.410"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0411: Sendable, Codable {
    public let id: String = "macos16-future.8.411"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0412: Sendable, Codable {
    public let id: String = "macos16-future.8.412"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0413: Sendable, Codable {
    public let id: String = "macos16-future.8.413"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0414: Sendable, Codable {
    public let id: String = "macos16-future.8.414"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0415: Sendable, Codable {
    public let id: String = "macos16-future.8.415"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0416: Sendable, Codable {
    public let id: String = "macos16-future.8.416"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0417: Sendable, Codable {
    public let id: String = "macos16-future.8.417"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0418: Sendable, Codable {
    public let id: String = "macos16-future.8.418"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0419: Sendable, Codable {
    public let id: String = "macos16-future.8.419"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0420: Sendable, Codable {
    public let id: String = "macos16-future.8.420"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0421: Sendable, Codable {
    public let id: String = "macos16-future.8.421"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0422: Sendable, Codable {
    public let id: String = "macos16-future.8.422"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0423: Sendable, Codable {
    public let id: String = "macos16-future.8.423"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0424: Sendable, Codable {
    public let id: String = "macos16-future.8.424"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0425: Sendable, Codable {
    public let id: String = "macos16-future.8.425"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0426: Sendable, Codable {
    public let id: String = "macos16-future.8.426"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0427: Sendable, Codable {
    public let id: String = "macos16-future.8.427"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0428: Sendable, Codable {
    public let id: String = "macos16-future.8.428"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0429: Sendable, Codable {
    public let id: String = "macos16-future.8.429"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0430: Sendable, Codable {
    public let id: String = "macos16-future.8.430"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0431: Sendable, Codable {
    public let id: String = "macos16-future.8.431"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0432: Sendable, Codable {
    public let id: String = "macos16-future.8.432"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0433: Sendable, Codable {
    public let id: String = "macos16-future.8.433"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0434: Sendable, Codable {
    public let id: String = "macos16-future.8.434"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0435: Sendable, Codable {
    public let id: String = "macos16-future.8.435"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0436: Sendable, Codable {
    public let id: String = "macos16-future.8.436"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0437: Sendable, Codable {
    public let id: String = "macos16-future.8.437"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0438: Sendable, Codable {
    public let id: String = "macos16-future.8.438"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0439: Sendable, Codable {
    public let id: String = "macos16-future.8.439"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0440: Sendable, Codable {
    public let id: String = "macos16-future.8.440"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0441: Sendable, Codable {
    public let id: String = "macos16-future.8.441"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0442: Sendable, Codable {
    public let id: String = "macos16-future.8.442"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0443: Sendable, Codable {
    public let id: String = "macos16-future.8.443"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0444: Sendable, Codable {
    public let id: String = "macos16-future.8.444"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0445: Sendable, Codable {
    public let id: String = "macos16-future.8.445"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0446: Sendable, Codable {
    public let id: String = "macos16-future.8.446"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0447: Sendable, Codable {
    public let id: String = "macos16-future.8.447"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0448: Sendable, Codable {
    public let id: String = "macos16-future.8.448"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0449: Sendable, Codable {
    public let id: String = "macos16-future.8.449"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0450: Sendable, Codable {
    public let id: String = "macos16-future.8.450"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0451: Sendable, Codable {
    public let id: String = "macos16-future.8.451"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0452: Sendable, Codable {
    public let id: String = "macos16-future.8.452"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0453: Sendable, Codable {
    public let id: String = "macos16-future.8.453"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0454: Sendable, Codable {
    public let id: String = "macos16-future.8.454"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0455: Sendable, Codable {
    public let id: String = "macos16-future.8.455"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0456: Sendable, Codable {
    public let id: String = "macos16-future.8.456"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0457: Sendable, Codable {
    public let id: String = "macos16-future.8.457"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0458: Sendable, Codable {
    public let id: String = "macos16-future.8.458"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0459: Sendable, Codable {
    public let id: String = "macos16-future.8.459"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0460: Sendable, Codable {
    public let id: String = "macos16-future.8.460"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0461: Sendable, Codable {
    public let id: String = "macos16-future.8.461"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0462: Sendable, Codable {
    public let id: String = "macos16-future.8.462"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0463: Sendable, Codable {
    public let id: String = "macos16-future.8.463"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0464: Sendable, Codable {
    public let id: String = "macos16-future.8.464"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0465: Sendable, Codable {
    public let id: String = "macos16-future.8.465"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0466: Sendable, Codable {
    public let id: String = "macos16-future.8.466"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0467: Sendable, Codable {
    public let id: String = "macos16-future.8.467"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0468: Sendable, Codable {
    public let id: String = "macos16-future.8.468"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0469: Sendable, Codable {
    public let id: String = "macos16-future.8.469"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0470: Sendable, Codable {
    public let id: String = "macos16-future.8.470"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0471: Sendable, Codable {
    public let id: String = "macos16-future.8.471"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0472: Sendable, Codable {
    public let id: String = "macos16-future.8.472"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0473: Sendable, Codable {
    public let id: String = "macos16-future.8.473"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0474: Sendable, Codable {
    public let id: String = "macos16-future.8.474"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0475: Sendable, Codable {
    public let id: String = "macos16-future.8.475"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0476: Sendable, Codable {
    public let id: String = "macos16-future.8.476"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0477: Sendable, Codable {
    public let id: String = "macos16-future.8.477"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0478: Sendable, Codable {
    public let id: String = "macos16-future.8.478"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0479: Sendable, Codable {
    public let id: String = "macos16-future.8.479"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0480: Sendable, Codable {
    public let id: String = "macos16-future.8.480"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0481: Sendable, Codable {
    public let id: String = "macos16-future.8.481"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0482: Sendable, Codable {
    public let id: String = "macos16-future.8.482"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0483: Sendable, Codable {
    public let id: String = "macos16-future.8.483"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0484: Sendable, Codable {
    public let id: String = "macos16-future.8.484"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0485: Sendable, Codable {
    public let id: String = "macos16-future.8.485"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0486: Sendable, Codable {
    public let id: String = "macos16-future.8.486"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0487: Sendable, Codable {
    public let id: String = "macos16-future.8.487"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0488: Sendable, Codable {
    public let id: String = "macos16-future.8.488"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0489: Sendable, Codable {
    public let id: String = "macos16-future.8.489"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0490: Sendable, Codable {
    public let id: String = "macos16-future.8.490"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0491: Sendable, Codable {
    public let id: String = "macos16-future.8.491"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0492: Sendable, Codable {
    public let id: String = "macos16-future.8.492"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0493: Sendable, Codable {
    public let id: String = "macos16-future.8.493"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0494: Sendable, Codable {
    public let id: String = "macos16-future.8.494"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0495: Sendable, Codable {
    public let id: String = "macos16-future.8.495"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0496: Sendable, Codable {
    public let id: String = "macos16-future.8.496"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0497: Sendable, Codable {
    public let id: String = "macos16-future.8.497"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0498: Sendable, Codable {
    public let id: String = "macos16-future.8.498"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0499: Sendable, Codable {
    public let id: String = "macos16-future.8.499"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0500: Sendable, Codable {
    public let id: String = "macos16-future.8.500"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0501: Sendable, Codable {
    public let id: String = "macos16-future.8.501"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0502: Sendable, Codable {
    public let id: String = "macos16-future.8.502"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0503: Sendable, Codable {
    public let id: String = "macos16-future.8.503"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0504: Sendable, Codable {
    public let id: String = "macos16-future.8.504"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0505: Sendable, Codable {
    public let id: String = "macos16-future.8.505"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0506: Sendable, Codable {
    public let id: String = "macos16-future.8.506"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0507: Sendable, Codable {
    public let id: String = "macos16-future.8.507"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0508: Sendable, Codable {
    public let id: String = "macos16-future.8.508"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0509: Sendable, Codable {
    public let id: String = "macos16-future.8.509"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0510: Sendable, Codable {
    public let id: String = "macos16-future.8.510"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0511: Sendable, Codable {
    public let id: String = "macos16-future.8.511"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0512: Sendable, Codable {
    public let id: String = "macos16-future.8.512"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0513: Sendable, Codable {
    public let id: String = "macos16-future.8.513"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0514: Sendable, Codable {
    public let id: String = "macos16-future.8.514"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0515: Sendable, Codable {
    public let id: String = "macos16-future.8.515"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0516: Sendable, Codable {
    public let id: String = "macos16-future.8.516"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0517: Sendable, Codable {
    public let id: String = "macos16-future.8.517"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0518: Sendable, Codable {
    public let id: String = "macos16-future.8.518"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0519: Sendable, Codable {
    public let id: String = "macos16-future.8.519"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0520: Sendable, Codable {
    public let id: String = "macos16-future.8.520"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0521: Sendable, Codable {
    public let id: String = "macos16-future.8.521"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0522: Sendable, Codable {
    public let id: String = "macos16-future.8.522"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0523: Sendable, Codable {
    public let id: String = "macos16-future.8.523"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0524: Sendable, Codable {
    public let id: String = "macos16-future.8.524"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0525: Sendable, Codable {
    public let id: String = "macos16-future.8.525"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0526: Sendable, Codable {
    public let id: String = "macos16-future.8.526"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0527: Sendable, Codable {
    public let id: String = "macos16-future.8.527"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0528: Sendable, Codable {
    public let id: String = "macos16-future.8.528"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0529: Sendable, Codable {
    public let id: String = "macos16-future.8.529"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0530: Sendable, Codable {
    public let id: String = "macos16-future.8.530"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0531: Sendable, Codable {
    public let id: String = "macos16-future.8.531"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0532: Sendable, Codable {
    public let id: String = "macos16-future.8.532"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0533: Sendable, Codable {
    public let id: String = "macos16-future.8.533"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0534: Sendable, Codable {
    public let id: String = "macos16-future.8.534"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0535: Sendable, Codable {
    public let id: String = "macos16-future.8.535"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0536: Sendable, Codable {
    public let id: String = "macos16-future.8.536"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0537: Sendable, Codable {
    public let id: String = "macos16-future.8.537"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0538: Sendable, Codable {
    public let id: String = "macos16-future.8.538"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0539: Sendable, Codable {
    public let id: String = "macos16-future.8.539"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0540: Sendable, Codable {
    public let id: String = "macos16-future.8.540"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0541: Sendable, Codable {
    public let id: String = "macos16-future.8.541"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0542: Sendable, Codable {
    public let id: String = "macos16-future.8.542"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0543: Sendable, Codable {
    public let id: String = "macos16-future.8.543"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0544: Sendable, Codable {
    public let id: String = "macos16-future.8.544"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0545: Sendable, Codable {
    public let id: String = "macos16-future.8.545"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0546: Sendable, Codable {
    public let id: String = "macos16-future.8.546"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0547: Sendable, Codable {
    public let id: String = "macos16-future.8.547"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0548: Sendable, Codable {
    public let id: String = "macos16-future.8.548"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0549: Sendable, Codable {
    public let id: String = "macos16-future.8.549"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0550: Sendable, Codable {
    public let id: String = "macos16-future.8.550"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0551: Sendable, Codable {
    public let id: String = "macos16-future.8.551"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0552: Sendable, Codable {
    public let id: String = "macos16-future.8.552"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0553: Sendable, Codable {
    public let id: String = "macos16-future.8.553"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0554: Sendable, Codable {
    public let id: String = "macos16-future.8.554"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0555: Sendable, Codable {
    public let id: String = "macos16-future.8.555"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0556: Sendable, Codable {
    public let id: String = "macos16-future.8.556"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0557: Sendable, Codable {
    public let id: String = "macos16-future.8.557"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0558: Sendable, Codable {
    public let id: String = "macos16-future.8.558"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0559: Sendable, Codable {
    public let id: String = "macos16-future.8.559"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0560: Sendable, Codable {
    public let id: String = "macos16-future.8.560"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0561: Sendable, Codable {
    public let id: String = "macos16-future.8.561"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0562: Sendable, Codable {
    public let id: String = "macos16-future.8.562"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0563: Sendable, Codable {
    public let id: String = "macos16-future.8.563"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0564: Sendable, Codable {
    public let id: String = "macos16-future.8.564"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0565: Sendable, Codable {
    public let id: String = "macos16-future.8.565"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0566: Sendable, Codable {
    public let id: String = "macos16-future.8.566"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0567: Sendable, Codable {
    public let id: String = "macos16-future.8.567"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0568: Sendable, Codable {
    public let id: String = "macos16-future.8.568"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0569: Sendable, Codable {
    public let id: String = "macos16-future.8.569"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0570: Sendable, Codable {
    public let id: String = "macos16-future.8.570"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0571: Sendable, Codable {
    public let id: String = "macos16-future.8.571"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0572: Sendable, Codable {
    public let id: String = "macos16-future.8.572"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0573: Sendable, Codable {
    public let id: String = "macos16-future.8.573"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0574: Sendable, Codable {
    public let id: String = "macos16-future.8.574"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0575: Sendable, Codable {
    public let id: String = "macos16-future.8.575"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0576: Sendable, Codable {
    public let id: String = "macos16-future.8.576"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0577: Sendable, Codable {
    public let id: String = "macos16-future.8.577"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0578: Sendable, Codable {
    public let id: String = "macos16-future.8.578"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0579: Sendable, Codable {
    public let id: String = "macos16-future.8.579"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0580: Sendable, Codable {
    public let id: String = "macos16-future.8.580"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0581: Sendable, Codable {
    public let id: String = "macos16-future.8.581"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0582: Sendable, Codable {
    public let id: String = "macos16-future.8.582"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0583: Sendable, Codable {
    public let id: String = "macos16-future.8.583"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0584: Sendable, Codable {
    public let id: String = "macos16-future.8.584"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0585: Sendable, Codable {
    public let id: String = "macos16-future.8.585"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0586: Sendable, Codable {
    public let id: String = "macos16-future.8.586"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0587: Sendable, Codable {
    public let id: String = "macos16-future.8.587"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0588: Sendable, Codable {
    public let id: String = "macos16-future.8.588"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0589: Sendable, Codable {
    public let id: String = "macos16-future.8.589"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0590: Sendable, Codable {
    public let id: String = "macos16-future.8.590"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0591: Sendable, Codable {
    public let id: String = "macos16-future.8.591"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0592: Sendable, Codable {
    public let id: String = "macos16-future.8.592"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0593: Sendable, Codable {
    public let id: String = "macos16-future.8.593"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0594: Sendable, Codable {
    public let id: String = "macos16-future.8.594"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0595: Sendable, Codable {
    public let id: String = "macos16-future.8.595"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0596: Sendable, Codable {
    public let id: String = "macos16-future.8.596"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0597: Sendable, Codable {
    public let id: String = "macos16-future.8.597"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0598: Sendable, Codable {
    public let id: String = "macos16-future.8.598"
    public init() {}
}

public struct CompatEntity_macos16_future_08_0599: Sendable, Codable {
    public let id: String = "macos16-future.8.599"
    public init() {}
}
